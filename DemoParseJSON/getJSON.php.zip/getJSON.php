<?php

require_once "connection.php";
header('Content-Type: application/json');
$data = mysql_query("SELECT * FROM data");
$arr = array();

while($row = mysql_fetch_array($data)){

	$id = $row["id"];
	$nameVideo = $row["NameVideo"];
	$linkVideo = $row["Link"];
	array_push($arr, new playlist($id,$nameVideo,$linkVideo));
}
$json = json_encode($arr,JSON_PRETTY_PRINT);

$format_json  = "{\n \"Result\": \n".$json."\n}";

echo $format_json;


class playlist {

	var $id;
	var $nameVideo;
	var $linkVideo;
	function playlist ($id, $nameVideo,$linkVideo,$imgName) {
		$this->id = $id;
		$this->nameVideo = $nameVideo;
		$this->linkVideo = $linkVideo;
	}
}

?>
